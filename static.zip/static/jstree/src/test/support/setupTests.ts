import jQuery from "jquery";
import "./jqTreeMatchers";

(window as any).$ = jQuery; // eslint-disable-line @typescript-eslint/no-unsafe-member-access
(window as any).jQuery = jQuery; // eslint-disable-line @typescript-eslint/no-unsafe-member-access
