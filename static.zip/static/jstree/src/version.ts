const version = "1.6.2";

export default version;
