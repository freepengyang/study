---
title: getSelectedNode
name: functions-getselectednode
---

Get the selected node. Returns the row data or false.

{% highlight js %}
var node = $tree.tree('getSelectedNode');
{% endhighlight %}
