---
title: addNodeBefore
name: functions-addnodebefore
---

**function addNodeBefore(new_node_info, existing_node);**

Add a new node before this existing node.
